import { Component } from '@angular/core';

@Component({
  selector: 'app-without-css',
  standalone: true,
  imports: [],
  templateUrl: './without-css.component.html',
  styles: ``
})
export class WithoutCssComponent {

}
