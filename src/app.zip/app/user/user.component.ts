import { Component } from '@angular/core';

@Component({
    selector: 'app-user',
    standalone: true,
    imports: [],
    templateUrl: './app/user.component.html',
    styleUrl: './app/user.component.css',
})
export class UserComponent {}
